package com.pranchiseeeee.common;

public interface AppService {

	void start();
	
}
